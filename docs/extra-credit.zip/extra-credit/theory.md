# Extra Credit Theory – DFD Fidelity, Canonical Models & RAG Implications

**Focus:** Understanding what is lost (and what is gained) when a visual Data Flow Diagram is turned into a structured JSON / graph representation, and how those losses affect every downstream RAG and evaluation step.

Welcome to the Extra Credit module. The core four weeks gave you a complete pipeline: high-quality chunking, hybrid + graph storage, modular skills, and automated evaluation. In real organizations one question keeps resurfacing:

> “We already have DFDs in Lucid, draw.io, Visio, or ThreatModeler. If we convert them to JSON so the RAG system can evaluate them, how much fidelity do we lose—and does it actually matter?”

This module answers that question with the same rigor we applied to retrieval and skills. Fidelity loss is real, but it is not uniform. Some losses are irrelevant (or even helpful). Others can silently break path queries, control matching, and the trustworthiness of the final compliance report.

---

## 1. Why a Structured Representation Is Necessary

A visual DFD is optimized for human consumption. A RAG-based compliance system needs a representation optimized for *machines*:

| Human visual DFD                          | Machine / RAG-ready model                          |
|-------------------------------------------|----------------------------------------------------|
| Spatial layout, colors, line styles       | Explicit nodes and typed edges                     |
| Implicit trust boundaries (dashed boxes)  | First-class `TrustBoundary` nodes + `CROSSES` edges |
| Free-text labels and notes                | Structured properties (classification, trust_level, protocol) |
| Ambiguous “DB1 → Service” arrows          | Directed `FLOWS_TO` edges with attributes          |

Without a canonical structured form, the skills you built in Week 3 (`check_trust_boundary_paths`, `match_security_controls`, `score_sdlc_compliance`) have nothing reliable to operate on. Graph path queries cannot run on pixels. Hybrid retrieval cannot filter on a property that exists only as a color.

The conversion step is therefore not optional—it is the bridge between the organization’s existing artifacts and the evaluation pipeline.

---

## 2. A Taxonomy of Fidelity Loss

Not all fidelity is equal. We distinguish four categories:

### 2.1 Visual / Layout Fidelity
Positions, sizes, alignment, colors, iconography, and decorative styling.

**Impact on RAG evaluation:** Almost zero.  
These elements rarely encode security-relevant facts. Losing them is usually beneficial because it removes noise.

### 2.2 Structural / Topological Fidelity
Which elements exist, how they connect, and which flows cross which trust boundaries.

**Impact on RAG evaluation:** High.  
Missing a trust boundary or an edge direction changes the answer to “Is there an unauthenticated path from External Entity X to Data Store Y?”. False negatives here are particularly dangerous in a compliance setting.

### 2.3 Semantic Fidelity
Attributes that give meaning to the topology: data classification, trust level of a process, authentication requirements on a flow, protocol, sensitivity of the data being moved.

**Impact on RAG evaluation:** High.  
A path may exist, but whether it *violates* a control often depends on these properties. If they are lost or left as free text, policy matching and scoring become incomplete or incorrect.

### 2.4 Provenance & Completeness Fidelity
Author, version, source tool, date, and any assumptions or notes that never became formal elements.

**Impact on RAG evaluation:** Medium to high for auditability.  
When a control decision is later challenged, “which version of the diagram was evaluated?” is a first-class question.

---

## 3. Implications for the RAG Pipeline

Fidelity problems do not stay confined to the conversion step. They propagate.

### 3.1 Retrieval (Weeks 1–2)
If the structured DFD lacks classification or trust-level properties, metadata pre-filters and hybrid queries cannot use them. The retriever may surface the wrong controls or fail to surface the right ones.

### 3.2 Graph-Augmented RAG (Lab 2.2)
Path queries are only as good as the graph. A missing `CROSSES` edge or an omitted TrustBoundary node produces both false negatives (“no violation found”) and false confidence.

### 3.3 Skills & Routing (Week 3)
- `validate_dfd_syntax` can catch many structural problems—if you give it a strict schema.
- `check_trust_boundary_paths` will silently miss violations when topology is incomplete.
- `match_security_controls` and `score_sdlc_compliance` inherit every upstream omission.

### 3.4 Evaluation & CI (Week 4)
Golden datasets and hit-rate / precision metrics become misleading if the input DFDs themselves are incomplete. You can achieve excellent scores on a flawed representation and still ship a system that fails on real diagrams.

### 3.5 Capstone & Production
The final ComplianceReport is only as trustworthy as the structured model that fed the skills. Auditability requires that the JSON (or graph) be treated as a controlled artifact, not a disposable export.

---

## 4. Design Patterns That Preserve What Matters

### 4.1 Canonical Schema First
Define a strict, versioned schema for DFD JSON (the course already uses a minimal version with `Process`, `DataStore`, `ExternalEntity`, `TrustBoundary` and typed edges). Make required security-relevant properties explicit rather than optional free text.

### 4.2 Validation as a First-Class Skill
The `validate_dfd_syntax` skill should do more than check that keys exist. It should enforce:

- Referential integrity of edges
- Presence of required properties for high-risk node types
- Explicit modeling of every trust-boundary crossing

### 4.3 Controlled Conversion, Not Blind Export
Prefer a conversion process that is:

- Tool-aware (different exporters lose different things)
- Reviewable (human or automated diff against the visual source for high-risk diagrams)
- Provenance-preserving (source tool, original file hash, converter version, operator)

### 4.4 Dual Representation Where Necessary
Keep the original visual artifact linked to the structured model. The visual remains the human-facing source of truth for discussion; the JSON/graph is the machine-facing source of truth for evaluation.

### 4.5 Progressive Enrichment
Start with topology. Add semantic properties in a second pass (classification, authentication, etc.). Do not require perfection on day one, but make incompleteness visible to the scoring skill.

---

## 5. Practical Decision Framework

```
Is the information only visual (layout, color, style)?
        │
        └─ YES → Accept the loss. Do not try to preserve it.

Is the information structural (nodes, edges, boundary crossings)?
        │
        └─ YES → Must be explicit in the JSON/graph. Validate strictly.

Is the information semantic (classification, trust level, authn, protocol)?
        │
        └─ YES → Prefer structured properties. If missing, surface the gap
                 in the compliance report rather than inventing values.

Is the information provenance or an author assumption?
        │
        └─ YES → Capture as metadata on the DfdDocument, not as a node.
```

---

## 6. Mapping to the Existing Course Artifacts

| Course component              | How fidelity issues appear                          | Mitigation already available / to extend |
|-------------------------------|-----------------------------------------------------|------------------------------------------|
| Week 1 chunking & metadata    | Controls retrieved without knowing data sensitivity | Richer metadata schema on DFD nodes      |
| Lab 2.2 Graph-Augmented RAG   | Missing paths or boundary crossings                 | Strict graph schema + validation         |
| Week 3 skills                 | Skills operate on incomplete inputs                 | Stronger `validate_dfd_syntax` + routing that refuses incomplete diagrams for high-risk routes |
| Week 4 evaluation             | Metrics computed on flawed fixtures                 | Include incomplete / lossy DFD fixtures in the golden set |
| Capstone                      | Final report trustworthiness                        | Require provenance + validation status in the ComplianceReport |

---

## Key Takeaways

- Visual fidelity loss is rarely a problem for RAG-based compliance evaluation; structural and semantic fidelity loss are real and consequential.
- The conversion from visual DFD to structured JSON/graph is a first-class design decision, not a mechanical export step.
- Every downstream component (retrieval, graph queries, skills, evaluation metrics, final report) inherits the quality of that structured model.
- Treat the JSON representation as a controlled artifact: versioned, validated, and linked back to its visual source.
- Explicitly surface incompleteness rather than silently inventing or ignoring missing attributes.

**Next:** Lab EC.1 turns these principles into a concrete canonical schema and validation skill. Lab EC.2 measures how different degrees of fidelity loss change the answers produced by the existing RAG and skill pipeline.

---

## Addendum: Mathematical & Formal Foundations

### A.1 Completeness of a Structured DFD

Let \(D_v\) be the visual diagram and \(D_s\) its structured representation.  
Define a set of security-relevant predicates \(P = \{p_1, p_2, \dots, p_m\}\) (e.g., “flow \(f\) crosses trust boundary \(b\)”, “data store \(s\) has classification confidential”).

The **structural completeness** of \(D_s\) relative to \(D_v\) can be expressed as:

\[
C_{\text{struct}}(D_s, D_v) = \frac{|\{p \in P_{\text{struct}} : p(D_s) = p(D_v)\}|}{|P_{\text{struct}}|}
\]

where \(P_{\text{struct}}\) is the subset of predicates that are topological.

Semantic completeness is defined analogously over \(P_{\text{sem}}\).

### A.2 Impact on Path-Based Evaluation

A trust-boundary violation query is essentially an existence check:

\[
\exists \text{ path } \pi : \text{ExternalEntity} \leadsto \text{DataStore}
\quad\text{such that}\quad
\pi \text{ crosses a TrustBoundary} \land \text{authn}(\pi) = \text{false}
\]

If any required edge or node is missing from \(D_s\), the existential quantifier evaluates to false even when the visual diagram contains the violation. This is a **false negative** whose probability grows with the incompleteness of the model.

### A.3 Propagation into Retrieval Precision

When downstream retrieval uses properties of \(D_s\) as filters or as part of the query text, missing attributes reduce the effective signal available to both the sparse and dense retrievers. In the limit, the hybrid score

\[
\text{score}_{\text{hybrid}}(d) = \alpha \cdot \text{sim}_{\text{dense}}(q, d) + (1-\alpha) \cdot \text{sim}_{\text{sparse}}(q, d)
\]

is computed against an impoverished query \(q\) derived from an incomplete \(D_s\), lowering both precision and recall of the governing controls.

### A.4 Validation as a Guard

Let \(V(D_s)\) be a validation function that returns a set of errors. A practical policy for high-risk routes is:

\[
\text{if } V(D_s) \neq \emptyset \text{ then refuse full evaluation route}
\]

This converts silent fidelity loss into an explicit, auditable failure—preferable in a compliance context.
